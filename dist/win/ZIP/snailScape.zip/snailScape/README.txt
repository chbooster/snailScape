This is an academic project, licensed under GNU General Public License v3.

This project was made at 2016 by Carlos Aniorte Llanes

For this project, third party software used was: SFML.
Language used is C++11 and was compiled with GCC 6.1.0 compiler (MinGW)

Thank you for give me your time to review my work.

Carlos Aniorte Llanes - 2018